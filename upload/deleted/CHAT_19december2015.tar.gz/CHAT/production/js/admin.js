"use strict";

// Функция для форматирования вида "{0} and {1}".format("drink","drive") ==> "drink and drive"
if (!String.prototype.format) {
    String.prototype.format = function() {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function(match, number) {
            return typeof args[number] != 'undefined' ? args[number] : match;
        });
    };
}

var clock = new Object;
clock.day = function() {
    return (new Date).getDate();
};
clock.month = function() {
    return (new Date).getMonth() + 1;
};
clock.year = function() {
    return (new Date).getFullYear();
};
clock.time = function() {
    return (new Date).toLocaleTimeString();
};
clock.data = function() {
    return String(clock.day() + '.' + clock.month() + '.' + clock.year());
};


var login = new Object;
login.isLogin = function() {
    if (sessionStorage["loginde"] == "failed") {
        return false
    }
    if (sessionStorage["loginde"] == undefined) {
        return false
    }
    if (sessionStorage["loginde"] == "success") {
        return true
    }
}

function reloadPage() {
    window.location.hostname = window.location.hostname;
}

function scrollToDiv(element) {
    var navheight = 15;
    var offset = element.offset();
    var offsetTop = offset.top;
    var totalScroll = offsetTop - navheight;

    $('body,html').animate({
        scrollTop: totalScroll
    }, 0);
}

function safe(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}    

function shortName(msg) {
    return safe(msg.title)[0] + '.' + ' ' + safe(msg.patronymic)[0] + '.' + ' ' + safe(msg.family);
}



$(document).ready(function() {


    // var $thisStroke=-1;
    var $laypass = $('.laypass');
    var $logout=$('.logout');
    var $body = $('body');
    session();    

    function showAuth() {
        // $laypass.show();
        $laypass.removeClass('hidden');
        $body.css('overflow', 'hidden');
    }

    function hideAuth() {
        // $laypass.hide();
        $laypass.addClass('hidden');
        $body.css('overflow', 'visible');
    }    


    $laypass.find("input[type=password]").keypress(function(e) {
        if ( (e.keyCode == 13) ) {
            sendVerefication();
        }
    });

    $('#login').click(function() {
        sendVerefication();
    });


function session() {
    if (!login.isLogin()) {
        showAuth();
    } else {
        hideAuth();
        console.log('Верефикация проверена');
        socket.emit('get_users_table', sessionStorage["from"]);
    }
}

function sendVerefication() {
    // console.log('send^'+$laypass.find('input[type=text]').val()+'---'+CryptoJS.MD5($laypass.find('input[type=password]').val()));
    sessionStorage["from"] = $laypass.find('input[type=text]').val();
    sessionStorage["pass"] = CryptoJS.MD5($laypass.find('input[type=password]').val());
    var from = sessionStorage["from"];
    var pass = sessionStorage["pass"];
    socket.emit("verification", {
        from,
        pass
    });
}


    socket.on('connecting', function() {
        // $('.msg').remove();
    });

    $('.users').keypress(function(e) {
        // return false;
        console.log(e);
        if ( (e.keyCode == 13) ) {
            return false; 
        }
    });     

    $('.add').click(function(e) {
        var nick="";
        var name="";
        var otch="";
        var family="";
        var pass="";
        var nicks=[];
        $(".user").each(function(indx, element){
             nicks.push($(element).find('.nick').text());
        });  
        console.log(nicks);
        while ((nick=="")|(_.include(nicks, nick.replace(/\ /g, "")))){            
            nick=prompt("Введите логин пользователя", "логин");
        }
        while(name==""){
            name=prompt("Введите имя пользователя", "");
        }
        while(otch==""){
            otch=prompt("Введите отчество пользователя", "");
        }  
        while(family==""){
            family=prompt("Введите фамилию пользователя", "");
        }   
        while(pass==""){
            pass=prompt("Введите пароль пользователя", "");
        }  
        $('.users').append('<span class="user"><span class="no">{5}</span><span  class="nick">{0}</span><span  class="name">{1}</span><span  class="otch">{2}</span><span  class="family">{3}</span><span  class="password">{4}</span></span>'.
                        format(nick, name,otch,family,pass, ""));
        var i=0;
        $(".user").each(function(indx, element){
            i++;
          $(element).find('.no').text(String(i));
        });    
    });    

    $('.users').on('click', '.user', function(e) {
        $(this).toggleClass('selectable');
        e.preventDefault();
        return false;
    });

    $('.users').on('dblclick', '.user', function(e) {
        $(this).children().each(function(index, el) {
            $(el).attr('contenteditable','true');
        });
        e.preventDefault();
        return false;
    });    

    $('.users').on('blur', '.user', function(e) {
        $(this).children().each(function(index, el) {
            $(el).attr('contenteditable','false');
        });
        e.preventDefault();
        return false;
    });        

    $('.delete').click(function(e) {

        $('.selectable').each(function(a, el) {
           $(el).remove();
        });

        var i=0;
        $(".user").each(function(indx, element){
            i++;
          $(element).find('.no').text(String(i));
        });        
    });


    socket.on('connect', function() {
    });

    socket.on('set_users_table', function(data) {
        var i=0;
        _.each(data, function(obj, login) {
            i++;
            var stroke ='<span user="{0}" class="user"><span class="no">{5}</span><span  class="nick">{0}</span><span  class="name">{1}</span><span  class="otch">{2}</span><span  class="family">{3}</span><span  class="password">{4}</span></span>'.
                        format(login, obj["имя"],obj["отчество"],obj["фамилия"],obj["pass"], String(i));
            $('.users').append(stroke);      
        });  
    });   


    $logout.click(function() {
        sessionStorage.clear();
        reloadPage();
    });    

    socket.on('failed', function() {
        sessionStorage["loginde"] = "failed";
        console.log('Верификация не пройдена, соединение не разорвано.');
        $laypass.find('input').addClass("redBorder")
    });

    socket.on('success', function() {
        hideAuth();
        sessionStorage["loginde"] = "success";
        $laypass.find('input').removeClass('redBorder');
        console.log('Верификация пройдена');
        socket.emit('get_users_table', sessionStorage["from"]);
        // socket.emit("dialog", down, sessionStorage["room"], false);
    });    

    $('.test').click(function() {
        $('.user').each(function(index, el) {
            var a = ['.nick','.otch','.name','.family','.password'];
            var $el = $(el);
            _.each(a, function(ix){
                if ($el.find(ix).text().replace(/\s+/g,'')=="") {
                    $el.find(ix).addClass('redBorder');
                }else{                    
                    $el.find(ix).removeClass('redBorder');
                }             
            });
            // $(el).find('.nick').text()
            // $(el).find('.otch').text()
            // $(el).find('.name').text()
            // $(el).find('.family').text()
            // $(el).find('.password').text()
        });
        if ($('.redBorder').length==0) {
            var users={};
            $('.user').each(function(index,el) {   
                if ($(el).find('.no').text()!="№") {
                    var nick=String($(el).find('.nick').text());
                    var name=String($(el).find('.name').text());
                    var otch=String($(el).find('.otch').text());
                    var family=String($(el).find('.family').text());
                    var password=String($(el).find('.password').text());

                    users[nick]={
                        "имя": name,
                        "отчество": otch,
                        "фамилия": family,
                        "pass": password
                       }

                }; 
            }); 

            // console.log(users);   
            socket.emit('write_users_table', users);
        };
    });
});

        //     "arzanova": {
        //     "имя": "Лариса",
        //     "отчество": "Иосифовна",
        //     "фамилия": "Аржанова",
        //     "pass": "180180"
        // },