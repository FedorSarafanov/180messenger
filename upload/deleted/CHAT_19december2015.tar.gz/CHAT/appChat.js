                                                                     
                                                                        
var socketPort = 8008,
    webPort = 8000,
    livereloadPort = 35729;

var messageBase = './json/base.json';
var cloudBase = './json/cloud.json';
var configBase = './json/config.json';


var IOoptions = { //Настройки socket.io
    'log level': 1
};

var colors = require('colors');

colors.setTheme({
    // silly: 'rainbow',
    // input: 'grey',
    // verbose: 'cyan',
    // prompt: 'grey',
    info: 'green',
    time: 'grey',
    use: 'cyan', 
    // help: 'cyan',
    warn: 'yellow',
    debug: 'blue',
    error: 'red'
});


var _ = require('./production/js/underscore-min.js'), //Underscore, известная библиотека, оптимизирующая работу с коллекциями
    crypto = require('crypto'); //MD5-хэш STRING по: crypto.createHash('md5').update(STRING).digest("hex")

var formidable = require('formidable'), //Парсинг ajax-формы с файлами
    iconv = require('iconv-lite'), //Перекодировка имен файлов в UTF-8
    fs = require('fs');


////////////////////////////////////////////////////////////////////////////////
///////////////////WEB-SERVER, LIVERELOAD, SOCKET.IO-SERVER/////////////////////
////////////////////////////////////////////////////////////////////////////////

var http = require('http'),
    express = require('express');

var socketApp = express(),
    socket_server = http.createServer(socketApp);

var io = require('socket.io').listen(socket_server, IOoptions);

socket_server.listen(socketPort); //Сервер-сокет

var siteApp = express(),
    site_server = http.createServer(siteApp);

var livereload = require('connect-livereload'); //LiveReload, отключить на продакшне

siteApp.use(require('connect-livereload')({
    port: livereloadPort
}));

site_server.listen(webPort); //Веб-сервер на неком порту

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////КОЛЛЕКЦИИ ДАННЫХ////////////////////////////////
////////////////////////////////////////////////////////////////////////////////


var messages = users = cloudfiles = colors = names = [];

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////ROUTES//////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

siteApp.use('/upload', express.static(__dirname + '/upload'));

//Для подключения папки с физическим адресом на виртуальный сделать:
// siteApp.use('/css',    express.static(__dirname + '/static/css'));
// siteApp.use('/font',   express.static(__dirname + '/static/font'));
// siteApp.use('/js',     express.static(__dirname + '/static/js'));
// Более простой вариант просто пробрасывает в / сайта физический адрес:
siteApp.use(express.static(__dirname + '/production'));
siteApp.use(express.static(__dirname + '/html'));

// siteApp.use(express.bodyParser());
siteApp.get('/', function(req, res) {
    res.sendFile(__dirname + '/html/index.html');
});

siteApp.get('/cloud.html', function(req, res) {
    res.sendFile(__dirname + '/html/cloud.html');
});


siteApp.engine('html', function(filePath, options, callback) { // движок

    fs.readFile(filePath, function(err, content) {

        if (err) return callback(new Error(err));

        var rendered = content.toString();

        switch (options.generate) {
            case "cloud":
                {
                    rendered = rendered
                        .replace('<!-- setroom -->', '<script> sessionStorage["room"]="' + options.room + '"; </script>')
                        .replace('<!-- endscript -->', '<script>$("section").hide();$(".files").find(".attached_tree").remove();socket.emit("cloud");$("#tomsg, #closeCloud").remove();$(".files").removeClass("hidden");</script>');
                    break
                }
            case "im":
                {
                    rendered = rendered
                        .replace('<!-- setroom -->', '<script> sessionStorage["room"]="' + options.room + '"; </script>')
                        .replace('<!-- endscript -->', '<script>$("section").hide();$(".im").removeClass("hidden");</script>');
                    break
                }
            case "default":
                {
                    rendered = rendered
                        .replace('<!-- setroom -->', '<script> sessionStorage["room"]="' + options.room + '"; </script>');
                    break
                }
            default:
                {}
        }

        return callback(null, rendered)
    })
})

siteApp.set('views', __dirname + '/'); // Только для views directory
siteApp.set('view engine', 'html'); // зарегистрируем движок

siteApp.get('/:room', function(req, res) {

    switch (req.params.room) {
        case "im":
            {
                res.render('./html/index', {
                    "generate": "im",
                    "room": req.params.room
                });
                break
            }
        case "cloud":
            {
                res.render('./html/index', {
                    "generate": "cloud",
                    "room": req.params.room
                });
                break
            }
        case "admin":
            {
                res.sendFile(__dirname + '/html//admin.html');
                break
            }
        case "bb":
            {
                res.sendFile(__dirname + '/html//backbone.html');
                break                
            }
        default:
            {
                res.render('./html/index', {
                    "generate": "default",
                    "room": req.params.room
                });
            }
    }
})

siteApp.post('/files/upload', function(req, res) {

    var form = new formidable.IncomingForm();

    form.uploadDir = __dirname + '/upload/';
    form.encoding = 'binary';

    var file = new Object;


    //TODO: Может ли быть такое, что parse выполниться позже end? 
    //Если это произойдет, то будет критическая ошибка с вылетом базы cloud.JSON,
    //которую придется править вручную.

    //ПРОВЕРЕНО:
    //Экспериментально, даже для файла с размером 0 бит и при одинаковом времени:
    //console.log(logTime()+'parse-'+new Date().getTime());
    //порядок выполнения кода и порядок функций parse, end совпадают.
    //TODO - ВЫПОЛНЕНО

    form.parse(req, function(err, fields, files) { //При присылке формы распасим её
        try {
            file.desc = fields.desc;
            file.size = fields.size;
            file.from = fields.from;
            file.file = files.files.name;
            file.path = files.files.path;
            file.data = fields.data;

            var buff = new Buffer(file.file, 'binary');
            file.file = iconv.decode(buff, 'utf8'); //Сразу в UTF-8 перегоним имя файла


            while (fs.existsSync(form.uploadDir + file.file)) {
                file.file = '_' + file.file;
            }
            //Костыль с переименованием файла.
            //TODO: придумать более элегантное версионирование, напр. по дате/времени.
        } catch (e) {
            console.log(logTime() + e);
        }
    });

    form.on('end', function() { //Событие по завершении загрузки

        try {
            console.log(file.path);
            console.log(form.uploadDir + file.file);
            fs.rename(file.path, form.uploadDir + file.file, function(err) {
                if (err) console.log(logTime() + 'ERROR: ' + err);
            });

            console.log(logTime() + "Загружен файл " + file.file.use + " в папку " + String(form.uploadDir).use + "пользователем " + file.from.info);

            var afile = {
                file: file.file,
                desc: file.desc,
                size: file.size,
                from: file.from,
                data: file.data
            }

            res.end(JSON.stringify(afile)); //Отправим на клиента ответ о загрузке файла
            cloudfiles.push(afile); //Добавим в коллекцию файл
            writeCloud(); //Запишем коллекцию на HDD

        } catch (e) {
            console.log(logTime() + " ERROR END " + e);
            //Тут должен быть какой-то client.emit, чтобы пользователь знал о ошибке,
            // а не ждал загрузки файла, хотя он уже не загружается из-за сбоя сервера.
        }
    });

});


////////////////////////////////////////////////////////////////////////////////
////////////////////////////ФУНКЦИИ, УЛУЧШАЮЩИЕ КОД/////////////////////////////
////////////////////////////////////////////////////////////////////////////////

function md5(name) {
    return crypto.createHash('md5').update(name).digest("hex");
}

function nick2fio(nick) {
    return names[nick]["фамилия"] + ' ' + names[nick]["имя"][0] + '. ' + names[nick]["отчество"][0] + '.';
}

var clock = new Object;
clock.day = function() {
    return (new Date).getDate();
};
clock.month = function() {
    return (new Date).getMonth() + 1;
};
clock.year = function() {
    return (new Date).getFullYear();
};
clock.time = function() {
    return (new Date).toLocaleTimeString();
};
clock.data = function() {
    return String(clock.day() + '.' + clock.month() + '.' + clock.year());
};

function logTime() {
    return '[' + String(clock.data() + '--' + clock.time()).time + '] ';
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////ФУНКЦИИ СБРОСА НА HDD///////////////////////////////
////////////////////////////////////////////////////////////////////////////////

function writeBase() {
    fs.writeFile(messageBase, JSON.stringify(messages, null, 4), function(err) {
        if (err) {
            console.log(logTime() + err);
        }
    })
}

function readBase() {
    messages = [];
    var contents = fs.readFileSync(messageBase);
    messages = JSON.parse(contents);
}

function readCloud() {
    cloudfiles = [];
    var cloudBaseStr = fs.readFileSync(cloudBase);
    cloudJSON = JSON.parse(cloudBaseStr);
    _.each(cloudJSON, function(content, number) {
        cloudfiles.push(content);
    });
}

function writeCloud() {
    fs.writeFile(cloudBase, JSON.stringify(cloudfiles, null, 4), function(err) {
        if (err) {
            console.log(logTime() + err);
        }
    })
}

function readSettings() {
    settings = users = names = colors = [];

    var contents = fs.readFileSync(configBase);
    settings = JSON.parse(contents);

    colors = settings[1];
    _.each(settings[0], function(num, key) {
        users.push(key);
        names[key] = num;
    });
}

function writeSettings() {
    fs.writeFile(configBase, JSON.stringify(settings, null, 4), function(err) {
        if (err) {
            console.log(logTime() + err);
        }
    })
}

////////////////////////////////////////////////////////////////////////////////
/////////////////////////ПРИ ЗАПУСКЕ ПРОЧТЕМ ВСЕ ИЗ ФАЙЛА///////////////////////
////////////////////////////////////////////////////////////////////////////////

readBase();
readSettings();
readCloud();

console.log(logTime() + "Запущен сервер".info);

////////////////////////////////////////////////////////////////////////////////
/////////////////////////////РАБОТА С КЛИЕНТАМИ/////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

io.sockets.on('connection', function(client) { //Всего 10 обработчиков

    var id = client.id;

    var ip = client.request.connection.remoteAddress;
    //Осторожно: это получение неоднократно менялось при обновлении node.js.

    if (1 != 1) {
        //Проверка на конец света, в положительном случае отключим клиента, чтобы не засорять
        //чистый пространственно-временной континиум какими-то левыми HTTP-сокет-пакетами.
        console.log(logTime() + 'Ошибка №42');
        client.disconnect();
    };

    client.on('verification', function(data) {
        //Верефикация login&pass. 
        //TODO: Приписывать client.id верефикационные данные, 
        //чтобы не костылить с небезопасной проверкой по имени залогиненного пользователя на клиента.
        try {
            console.log(logTime() + 'Попытка входа с IP ' + ip + ', ID ' + id + ' под данными: md5(pass)=' + data["pass"] + ', login=' + data["from"]);
            if (md5(names[data["from"]]["pass"]) != data["pass"]) {
                client.emit('failed');
                console.log(logTime() + 'Неверное имя пользователя/пароль. Не аутенфицирован.'.warn);
            } else {
                client.emit('success');
                console.log(logTime() + 'Успешная аутенфикация'.info);
            }
        } catch (e) {
            console.log(logTime() + e);
        }
    });

    client.on('message', function(message) {
        //Событие   п р и ш е д ш е г о   сообщения.
        //Данные сообщения детализируются по времени сервера. 
        //!: это не допустит ошибок с некорректным временем на client's computer.
        try {
            message.time = clock.time();
            message.day = clock.day();
            message.month = clock.month();
            message.year = clock.year();
            message.ip = ip;

            _.each(colors, function(role, user) {
                //Проверка пользователя на админские/директорские привилегии
                if (message.from == user) {
                    message.color = role;
                };
            });
            message.family = names[message.from]["фамилия"]; // Фамилия отправителя
            message.title = names[message.from]["имя"]; // Имя отправителя
            message.patronymic = names[message.from]["отчество"]; // Отчество отправителя

            //Добавить сообщение в базу
            messages.push(message); 

            //Записать базу, добавив сообщение
            //TODO: писать базу только при завершении сервера или по таймеру.
            //Кстати, именно этим объясняется неповоротливость на 100'000 сообщений
            writeBase();

            client.emit('message', message, true); //Отправить отправившему запрос
            client.broadcast.emit('message', message, true); //Отправить всем клиентам сообщение
        } catch (e) {
            console.log(logTime() + e);          
        }
    });

    client.on('dialog', function(length, room, bottom) {
        try {

            // readBase(); //В случае некорректной работы раскомментировать

            for (var i = messages.length - 1; i >= 0; i--) {
                if ((messages[i].day >= clock.day() - length) & (messages[i].month == clock.month()) & (messages[i].year == clock.year())) {
                    if (messages[i].room == room) {
                        if (JSON.stringify(_.findWhere(messages, {
                                "room": room
                            })) == JSON.stringify(messages[i])) {
                            // console.log(logTime()+'Отослано последнее сообщение');
                            client.emit('lockBottom');
                        }
                        client.emit('message', messages[i], false);
                        if (bottom) {
                            client.emit('scrollBottom')
                        }
                    }
                } else {
                    if (bottom) {
                        client.emit('scrollBottom')
                    }
                    break;
                }
            }
        } catch (e) {
            console.log(logTime() + e);
        }
    });

    client.on('removeMsg', function(time, message, from, to) {
        try {
            messages = _.compact(_.without(messages, _.findWhere(messages, {
                "time": time,
                "from": from
            })));

            client.broadcast.emit('removeMsg', from, time);
            writeBase(); //Записать базу, удалив сообщение.
            //TODO: писать базу только при завершении сервера или по таймеру.

        } catch (e) {
            console.log(logTime() + e);
        }
    })

    client.on('removeFile', function(file) {
        try {
            console.log(logTime() + "Удален файл " + file + " из папки '" + __dirname + "/upload/'");

            cloudfiles = _.compact(_.without(cloudfiles, _.findWhere(cloudfiles, {
                "file": file
            })));

            fs.rename(__dirname + '/upload/' + file, __dirname + '/upload/deleted/' + file, function(err) {
                if (err) console.log(logTime() + 'ERROR: ' + err);
            });

            writeCloud();

        } catch (e) {
            console.log(logTime() + e);
        }
    })


    client.on('cloud', function(length) {
        try {

            cloudfiles = [];
            readCloud();
            var d = cloudfiles.length;
            for (var i = 0; i <= d - 1; i++) {
                // console.log(logTime()+cloudfiles[i]);
                // if ((messages[i].day>=(new Date).getDate()-length)&(messages[i].month==(new Date).getMonth()+1)&(messages[i].year==(new Date).getFullYear())){
                client.emit('file_to_cloud', cloudfiles[i]);
                // }
            };

        } catch (e) {
            console.log(logTime() + e);
        }
    });

    client.on('get_users', function() {
        try {
            var usersArray = [];
            // console.log(users);
            for (var i = 0; i < users.length; i++) {
                // console.log(users[i]);
                usersArray.push({
                    title: nick2fio(users[i]),
                    from: users[i]
                });
            };
            client.emit('add_users', usersArray);

        } catch (e) {
            console.log(logTime() + e);
        }
    });

    client.on('get_users_table', function(user) { //Выполним только если у user есть админская группа
        try {
            console.log(logTime() + 'Запрос таблицы пользователей с IP ' + ip + ', ID ' + id + ' пользователем ' + user);
            if (colors[user] == "adminName") {
                client.emit('set_users_table', settings[0]);
            } else {
                // client.disconnect();
            }
        } catch (e) {
            console.log(logTime() + e);
        }
    });

    client.on('write_users_table', function(usersArr) {
        try {
            console.log(logTime() + 'Запрос записи таблицы пользователей с IP ' + ip + ', ID ' + id);
            settings[0] = usersArr;
            writeSettings();

            users = [];
            names = [];

            _.each(settings[0], function(num, key) {
                users.push(key);
                names[key] = num;
            });

        } catch (e) {
            console.log(logTime() + e);
        }
    });

    client.on('editMsg', function(src, time, from, out) {
        try {
            //Найдем первое вхождение такого сообщения с конца,
            //для экономии памяти
            var index = _.findLastIndex(messages, {
                from: from,
                time: time,
                message: src
            });

            messages[index].message = out;

            //Записать базу, добавив сообщение 
            //TODO: писать базу только при завершении сервера или по таймеру.
            writeBase();
        } catch (e) {
            console.log(logTime() + e);
        }
    });


    client.on("error", function(err) { //Пока эта функция не нужна, но в будущем, возможно, понадобится
        try {
            console.log(logTime() + "Универсальный обработчик ошибки вернул: " + err);
        } catch (e) {
            console.log(logTime() + "Ошибка при выводе ошибки! Что-то несусветное.");
        }
    });

});