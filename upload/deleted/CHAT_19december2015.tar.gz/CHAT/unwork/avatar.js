//All right reserved (c) 2015
function life (age) {	
	surrenderSession();
	markBirthday("30.08.19xx", 
		function (argument) {		
		feelSad();// callback
	});	
	writeCode({"limit":"infinity"});
	age+=1;
	life(age);
}