#!/usr/bin/env bash
node /home/osabio/CHAT/server/appChat.js